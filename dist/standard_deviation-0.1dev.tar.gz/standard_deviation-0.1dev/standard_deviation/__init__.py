# A package for calculating stdev
