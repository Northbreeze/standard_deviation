from distutils.core import setup
setup(
    name='standard_deviation',
    version='0.1dev',
    packages=['standard_deviation',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
