**Standard deviation**

# What is it?
standard deviation is a Python package calculates the standard deviation.

# Where to get it?

The source code is currently hosted on GitHub at: https://github.ubc.ca/nasimtab/standard_devation

My partner should run the following:
pip install git+git@github.ubc.ca:nasimtab/standard_devation.git
